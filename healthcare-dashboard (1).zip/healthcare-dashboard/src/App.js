import React from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import DashboardMainContent from './components/DashboardMainContent';
import './App.css';

function App() {
  return (
    <div className="app-container">
      <Sidebar />
      <main>
        <Header />
        <DashboardMainContent />
      </main>
    </div>
  );
}

export default App;