# Healthcare Dashboard
Static healthcare dashboard UI built with React.