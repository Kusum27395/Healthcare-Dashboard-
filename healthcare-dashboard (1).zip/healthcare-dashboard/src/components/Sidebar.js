import React from 'react';
import './Sidebar.css';

function Sidebar() {
  return (
    <div className="sidebar">
      <h2>Healthcare.</h2>
      <ul>
        <li>Dashboard</li>
        <li>History</li>
        <li>Calendar</li>
        <li>Appointments</li>
        <li>Statistics</li>
        <li>Chat</li>
        <li>Support</li>
        <li>Setting</li>
      </ul>
    </div>
  );
}

export default Sidebar;